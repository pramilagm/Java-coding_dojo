package com.codingdojo.ZooKeeper;

public class GorrilaTest {
	public static void main(String[] args) {
		Gorilla activity = new Gorilla(30);
		activity.throwSomething();
		activity.throwSomething();
		activity.throwSomething();
		activity.eatBananas();
		activity.eatBananas();
		activity.climb();
	}

}
