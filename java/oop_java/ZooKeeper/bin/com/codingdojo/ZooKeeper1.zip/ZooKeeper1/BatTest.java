package com.codingdojo.ZooKeeper1;


public class BatTest {
	public static void main(String[] args) {
		Bat activity = new Bat();
		activity.attackTown();
		activity.attackTown();
		activity.attackTown();
		activity.eatHumans();
		activity.eatHumans();
		activity.fly();
		activity.fly();
		
	}

}
