package com.chughes.login.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.chughes.login.model.Task;
import com.chughes.login.service.TaskService;
import com.chughes.login.service.UserService;



@Controller
public class TaskController {
	private final TaskService taskService;
	private final UserService userService;
	public TaskController(TaskService taskService, UserService userService) {
		this.taskService = taskService;
		this.userService = userService;
	}
	 @RequestMapping("/tasks")
	 public String home(Model model, HttpSession session, @ModelAttribute("task") Task task,BindingResult result) {
	     // get user from session, save them in the model and return the home page
		 Long userId = (Long) session.getAttribute("user_id");
		 if (userId == null) {
			 return "redirect:/";
			
		 }
		 model.addAttribute("user", userService.findUserById(userId));
		 List<Task> tasks = taskService.findAllTask();
		 model.addAttribute("tasks" ,tasks);
		 return "homePage.jsp";
	 }
	 @RequestMapping("/tasks/new")
	 public String newTask(@ModelAttribute("task") Task task,HttpSession session, Model model){
		 Long userId = (Long) session.getAttribute("user_id");
		 if (userId == null) {
			 
			 
			 return "redirect:/";
		 }
//		 GRAB ALL USERS AND PASS IT TO JSP
		 model.addAttribute("user", userService.findUserById(userId));
		 model.addAttribute("users", userService.findAllUser());
		 return "newTask.jsp";
		 
	 }
	 
	 @RequestMapping(value ="/tasks/new/create",method =RequestMethod.POST)
		public String taskCreate(@Valid @ModelAttribute("task") Task task, BindingResult result, Model model,HttpSession session) {
			if(result.hasErrors()) {
				 model.addAttribute("users", userService.findAllUser());
				return "newTask.jsp";
			}
			
			 Long userId = (Long) session.getAttribute("user_id");
			 if (userId == null) {
				 return "redirect:/";
			 }  
			        model.addAttribute("user", userService.findUserById(userId));
		            taskService.createTask(task);
		            return "redirect:/tasks";
		}
	 @RequestMapping("/tasks/{task_id}")
	 public String showTask(@PathVariable("task_id")Long taskId, Model model ,HttpSession session){
		 Long userId = (Long) session.getAttribute("user_id");
		 if (userId == null) {
			 return "redirect:/";
		 }
		  model.addAttribute("user", userService.findUserById(userId));
		  model.addAttribute("task", taskService.findTaskById(taskId));
		 return "showTask.jsp";	 
	 }
	 @RequestMapping("/tasks/{id}/edit")
	 public String editTask(@PathVariable("id") Long taskId, Model model ,HttpSession session){
		 Long userId = (Long) session.getAttribute("user_id");
		 if (userId == null) {
			 return "redirect:/";
		 }
		  model.addAttribute("user", userService.findUserById(userId));
		  model.addAttribute("task", taskService.findTaskById(taskId));
		  model.addAttribute("users", userService.findAllUser());
		  
		 return "editTask.jsp";	 
	 }
	 @RequestMapping(value ="/tasks/{id}/update", method = RequestMethod.PUT)
		public String updateEvent(@Valid @ModelAttribute("task") Task task,BindingResult result,@PathVariable("id")Long taskId,HttpSession session,Model model ) {
		 	Long userId = (Long) session.getAttribute("user_id");
			if(result.hasErrors()) {
				 model.addAttribute("users", userService.findAllUser());
				 model.addAttribute("user", userService.findUserById(userId));
				 
				return "editTask.jsp";
			}
			
			if(userId==null) {
				return "redirect:/";
			}
			
			taskService.updateTask(task);
			return "redirect:/tasks";
	 }
			
	 	
	 @RequestMapping("/tasks/{task_id}/delete")
		public String deletEvent(@PathVariable("task_id")Long taskId,HttpSession session) {
			 Long userId = (Long) session.getAttribute("user_id");
			if (userId == null) {
				 return "redirect:/"; 
			 }
			taskService.DeleteTask(taskId);
			return "redirect:/tasks";
		}
	
	 
	 
	 
	 @RequestMapping("/tasks/logout")
	 public String logout(HttpSession session) {
	     // invalidate session
	     // redirect to login page
		 session.invalidate();
		 return "redirect:/";
	 }

}
