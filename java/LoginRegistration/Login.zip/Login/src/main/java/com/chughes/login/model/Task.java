package com.chughes.login.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="tasks")
public class Task {
	@Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	 private Long id;
	@Size(min=1, max= 200, message="Please enter a name")
	 private String taskName;
	@Size(min=1, message="cannot be Empty")
	 private String priority;
	 @ManyToOne(fetch = FetchType.LAZY)
	 @JoinColumn(name="user_id")
	 private User assignee;
	 
//	 @Size(min=1, message="cannot be Empty")
	 @ManyToOne(fetch = FetchType.LAZY)
	 @JoinColumn(name="creator_id")
	 private User creator;
	 
	public Task() {
		
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public User getAssignee() {
		return assignee;
	}
	public void setAssignee(User assignee) {
		this.assignee = assignee;
	}
	public User getCreator() {
		return creator;
	}
	public void setCreator(User creator) {
		this.creator = creator;
	}
	

}
