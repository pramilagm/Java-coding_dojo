package com.chughes.login.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="creators")
public class Creator {
	 @Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	 private Long id;
	 @Size(min=1, max= 30)
	 private String name;
	 @OneToMany(mappedBy="creator", fetch = FetchType.LAZY)
	 private List<Task> createdtask;
	 
	 public Creator() {
		 
	 }
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public List<Task> getCreatedtask() {
		return createdtask;
	}
	public void setCreatedtask(List<Task> createdtask) {
		this.createdtask = createdtask;
	}
	 
	

}
