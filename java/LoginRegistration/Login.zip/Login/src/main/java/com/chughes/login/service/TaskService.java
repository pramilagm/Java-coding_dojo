package com.chughes.login.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.chughes.login.model.Task;
import com.chughes.login.repository.TaskRepository;
import com.chughes.login.repository.UserRepository;

@Service
public class TaskService {
	private final TaskRepository taskRepo;
	private final UserRepository userRepo;
	public TaskService(TaskRepository taskRepo, UserRepository userRepo) {
		this.taskRepo = taskRepo;
		this.userRepo = userRepo;
	}
	
	public List<Task> findAllTask(){
		return taskRepo.findAll();
	}

	public Task createTask(Task task) {
		return taskRepo.save(task);
		
	}

	public Task findTaskById(Long taskId) {
		return taskRepo.findById(taskId).orElse(null);
		
	}

	public void updateTask(@Valid Task task) {
       taskRepo.save(task);
		
		
	}

	public void DeleteTask(Long taskId) {
		taskRepo.deleteById(taskId);
		
	}

}
