package com.chughes.login.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.chughes.login.model.Task;
import com.chughes.login.model.User;
import com.chughes.login.service.UserService;

@Controller
public class UserController {
 private final UserService userService;
 
 public UserController(UserService userService) {
     this.userService = userService;
 }
 @RequestMapping("/")
 public String index( @ModelAttribute("user") User user) {
	 return "registrationPage.jsp";
 }
 
 @RequestMapping("/registration")
 public String registerForm(@ModelAttribute("user") User user) {
     return "homePage.jsp";
 }
 @RequestMapping("/login")
 public String login() {
     return "homePage.jsp";
 }
 
 @RequestMapping(value="/registration", method=RequestMethod.POST)
 public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
     // if result has errors, return the registration page (don't worry about validations just now)
     // else, save the user in the database, save the user id in session, and redirect them to the /home route
	 if (result.hasErrors()) {
		 return "registrationPage.jsp";
	 }else {
		 userService.registerUser(user);
		 session.setAttribute("user_id", user.getId());
		 return "redirect:/tasks";
	 }
 }
 
 @RequestMapping(value="/login", method=RequestMethod.POST)
 public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model, HttpSession session,RedirectAttributes attribute) {
     // if the user is authenticated, save their user id in session
     // else, add error messages and return the login page
	 if (email.length() < 1) {
			attribute.addFlashAttribute("loginError", "Must enter an email");
			return "redirect:/";
		} else if (password.length() < 1) {
			attribute.addFlashAttribute("loginError", "Must enter a password");
			return "redirect:/";
		} else if (userService.authenticateUser(email, password)) {
			User user = userService.findByEmail(email);
			if (user == null) {
				attribute.addFlashAttribute("loginError", "User does not exist");
			} else {
				session.setAttribute("user_id", user.getId());
				session.setAttribute("loggedIn", true);
				return "redirect:/tasks";
			}
		} else {
			attribute.addFlashAttribute("loginError", "Invalid Password");
		}
		return "redirect:/";
	}
 }
 

 
